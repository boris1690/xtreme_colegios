<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" lang="en-US">
<![endif]-->
<!--[if IE 7]>
<html id="ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html id="ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US" xmlns:fb="http://ogp.me/ns/fb#">
<!--<![endif]-->
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=9"/>
<title>Page not found | Bostan</title>
<link rel="profile" href="http://gmpg.org/xfn/11"/>
 
<link rel="pingback" href="http://ahmad.works/bostan/xmlrpc.php"/>
 
 
<!--[if lt IE 9]>
<script src="http://ahmad.works/bostan/wp-content/themes/bostan/js/html5.js"></script>
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" href="http://ahmad.works/bostan/wp-content/themes/bostan/framework/fontawesome/css/font-awesome-ie7.min.css">
<![endif]-->
<noscript>
</noscript>
<meta name='robots' content='noindex,follow'/>
<link rel="alternate" type="application/rss+xml" title="Bostan &raquo; Feed" href="http://ahmad.works/bostan/feed/"/>
<link rel="alternate" type="application/rss+xml" title="Bostan &raquo; Comments Feed" href="http://ahmad.works/bostan/comments/feed/"/>
<link rel='stylesheet' id='aqpb-view-css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/aqua/assets/css/aqpb-view.css?ver=1433908950' type='text/css' media='all'/>
<link rel='stylesheet' id='contact-form-7-css' href='http://ahmad.works/bostan/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.1.1' type='text/css' media='all'/>
<link rel='stylesheet' id='rs-plugin-settings-css' href='http://ahmad.works/bostan/wp-content/plugins/revslider/rs-plugin/css/settings.css?ver=4.6.5' type='text/css' media='all'/>
<style id='rs-plugin-settings-inline-css' type='text/css'>.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}</style>
<link rel='stylesheet' id='wp-syntax-css-css' href='http://ahmad.works/bostan/wp-content/plugins/wp-syntax/css/wp-syntax.css?ver=1.0' type='text/css' media='all'/>
<link rel='stylesheet' id='pricing-base-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/wp-pricing-table/css/base.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='pricing-layout-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/wp-pricing-table/css/layout.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='pricing-fluid-skeleton-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/wp-pricing-table/css/fluid_skeleton.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='pricing-table-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/wp-pricing-table/css/pricing_table.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='opensans-css' href='http://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C700italic%2C800italic%2C400%2C800%2C700%2C600%2C300&#038;ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_bootstrap_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/bootstrap/css/bootstrap.min.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_fontello_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/fontello/css/fontello.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_fontelloanimation_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/framework/fontello/css/animation.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_flexslider_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/js/flexslider/flexslider.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_galleryslider_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/js/flexslider/galleryslider.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_shortcodes_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/inc/shortcodes/style.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_tweets_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/js/tweets/jquery.tweet.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_prettyphoto_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/js/prettyphoto/css/prettyPhoto.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_isotope_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/js/isotope/style.css?ver=1' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_owl_carousel_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/js/owl-carousel/owl.carousel.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_owl_theme_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/js/owl-carousel/owl.theme.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_main_style-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/style.css?ver=3.1' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_responsive_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/responsive.css?ver=2.3' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_switcher_css-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/switcher/switcher.css?ver=4.1.5' type='text/css' media='all'/>
<link rel='stylesheet' id='asalah_switcher_css_picker-css' href='http://ahmad.works/bostan/wp-content/themes/bostan/switcher/colorpicker/css/colorpicker.css?ver=4.1.5' type='text/css' media='all'/>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-includes/js/jquery/jquery.js?ver=1.11.1'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min.js?ver=4.6.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min.js?ver=4.6.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/modernizr.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/switcher/colorpicker/js/color-picker.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/switcher/switcher.js?ver=2.6'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ahmad.works/bostan/xmlrpc.php?rsd"/>
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ahmad.works/bostan/wp-includes/wlwmanifest.xml"/>
<meta name="generator" content="WordPress 4.1.5"/>
<script type="text/javascript">
			jQuery(document).ready(function() {
				// CUSTOM AJAX CONTENT LOADING FUNCTION
				var ajaxRevslider = function(obj) {
				
					// obj.type : Post Type
					// obj.id : ID of Content to Load
					// obj.aspectratio : The Aspect Ratio of the Container / Media
					// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content
					
					var content = "";

					data = {};
					
					data.action = 'revslider_ajax_call_front';
					data.client_action = 'get_slider_html';
					data.token = 'b97da17c76';
					data.type = obj.type;
					data.id = obj.id;
					data.aspectratio = obj.aspectratio;
					
					// SYNC AJAX REQUEST
					jQuery.ajax({
						type:"post",
						url:"http://ahmad.works/bostan/wp-admin/admin-ajax.php",
						dataType: 'json',
						data:data,
						async:false,
						success: function(ret, textStatus, XMLHttpRequest) {
							if(ret.success == true)
								content = ret.data;								
						},
						error: function(e) {
							console.log(e);
						}
					});
					
					 // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
					 return content;						 
				};
				
				// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
				var ajaxRemoveRevslider = function(obj) {
					return jQuery(obj.selector+" .rev_slider").revkill();
				};

				// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
				var extendessential = setInterval(function() {
					if (jQuery.fn.tpessential != undefined) {
						clearInterval(extendessential);
						if(typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
							jQuery.fn.tpessential.defaults.ajaxTypes.push({type:"revslider",func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});   
							// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
							// func: the Function Name which is Called once the Item with the Post Type has been clicked
							// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
							// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
						}
					}
				},30);
			});
		</script>
<meta property="og:site_name" content="Bostan"/>
<meta property="og:description" content="Wordpress Theme For Business."/>
<meta property="og:type" content="website"/>
<meta property="og:image" content='http://ahmad.works/bostan/wp-content/themes/bostan/img/default.jpg'/>
<meta property="og:url" content="http://ahmad.works/bostan"/>
<style>.page_title_holder{background-image:url('http://ahmad.works/bostan/wp-content/uploads/2013/06/header_title.jpg');background-repeat:no-repeat;}body{}a{}h1{}h2{}h3{}h4{}h5{}h6{}.contact_info_item{}.below_header .navbar .nav>li>a{}.page-header a{}.services_info h3{}.portfolio_info h5{}.blog_title h4{}.widget_container h3{}.site_footer{}.site_footer a{}.site_secondary_footer{}.site_secondary_footer a{}.page_title_holder h1{}html{background-image:url('http://ahmad.works/bostan/wp-content/themes/bostan/images/bg/bg41.png');}.logo{margin-top:30px;}.main_navbar{margin-top:20px;}.logo img{width:302px;height:62px;}.page_title_holder h1{color:#fff;}.page_title_holder a{color:#fff;}.clients_list li img{float:left;width:100%;}.portfolio_thumbnail img{border-radius:4px;width:100%;}.page_title_holder{color:#fff;}.logo img{width:302px;height61px;}img{width:auto10!important;}</style> </head>
<body class="error404 body_width">
 
<div id="fb-root"></div>
<script>
                window.fbAsyncInit = function() {
                FB.init({
                    status     : true, // check login status
                        cookie     : true, // enable cookies to allow the server to access the session
                        xfbml      : true  // parse XFBML
                });
                };
                        // Load the SDK Asynchronously
                                (function(d){
                                var js, id = 'facebook-jssdk'; if (d.getElementById(id)) {return; }
                                js = d.createElement('script'); js.id = id; js.async = true;
                                        js.src = "//connect.facebook.net/en_US/all.js";
                                        d.getElementsByTagName('head')[0].appendChild(js);
                                }(document));
            </script>
 
 
<header class="header_container body_width">
 
<div class="container-fluid top_header">
<div class="container">
<div class="row-fluid">
 
<div class="top_header_tools_holder pull-right">
<div class="header_items_line ">
<div class="social_icons pull-right">
<ul class="social_icons_list clearfix">
<li><a href="https://twitter.com/#" target="_blank"><i class="icon-twitter" title="Twitter"></i></a></li>
<li><a href="#" target="_blank"><i class="icon-facebook" title="Facebook"></i></a></li>
<li><a href="#" target="_blank"><i class="icon-gplus" title="Google Plus"></i></a></li>
<li><a href="#" target="_blank"><i class="icon-linkedin" title="Linkedin"></i></a></li>
<li><a href="#" target="_blank"><i class="icon-youtube" title="Youtube"></i></a></li>
<li><a href="#" target="_blank"><i class="icon-vimeo" title="Vimeo"></i></a></li>
<li><a href="#" target="_blank"><i class="icon-flickr" title="Flickr"></i></a></li>
<li><a href="http://ahmad.works/bostan/feed/" target="_blank"><i class="icon-rss top_menu_icon"></i></a></li>
</ul>
</div>
</div>
</div>
 
 
<div class="contact_info_holder">
<div class="contact_info_line">
<i class="icon-mail contact_info_icon"></i> <span class="mail_address contact_info_item"><a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="27464f4a464367460a54464b464f0944484a">[email&#160;protected]</a><script cf-hash='f9e31' type="text/javascript">
/* <![CDATA[ */!function(){try{var t="currentScript"in document?document.currentScript:function(){for(var t=document.getElementsByTagName("script"),e=t.length;e--;)if(t[e].getAttribute("cf-hash"))return t[e]}();if(t&&t.previousSibling){var e,r,n,i,c=t.previousSibling,a=c.getAttribute("data-cfemail");if(a){for(e="",r=parseInt(a.substr(0,2),16),n=2;a.length-n;n+=2)i=parseInt(a.substr(n,2),16)^r,e+=String.fromCharCode(i);e=document.createTextNode(e),c.parentNode.replaceChild(e,c)}}}catch(u){}}();/* ]]> */</script></span>
<i class="icon-phone-outline contact_info_icon"></i> <span class="phone_number contact_info_item">+2-012-24627169</span>
</div>
</div>
 
</div>
</div>
</div>
 
 
<div id="below_header" class="container-fluid body_width below_header headerissticky">
<div class="container">
<div class="row"><div id="below_header_span" class="span12">
<div class="row-fluid">
<div class="logo">
<a class="default_logo" href="http://ahmad.works/bostan" title="Bostan"><h1><img width="302" height="62" src="http://ahmad.works/bostan/wp-content/uploads/2013/06/logo_large1.png" alt="Bostan"><strong class="hidden">Bostan</strong></h1></a>
<a class="retina_logo" href="http://ahmad.works/bostan" title="Bostan"><h1><img width="302" height="62" src="http://ahmad.works/bostan/wp-content/uploads/2013/06/logo_large1.png" alt="Bostan"><strong class="hidden">Bostan</strong></h1></a>
</div>
<div id="gototop" title="Scroll To Top" class="gototop pull-right">
<i class="icon-up-open"></i>
</div>
<nav class="span visible-desktop span navbar main_navbar pull-right">
<div class="main_nav"><ul id="menu-main-menu" class="nav"><li id="menu-item-23790" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown"><a href="http://projects.asalahsolutions.com/bostan/" data-target="#" tabindex="-1" data-hover="dropdown" data-delay="200" role="button" class="dropdown-toggle"><span class="menu_icon"><i class="icon-home"></i></span>Home<b class="caret"></b></a>
<ul class="dropdown-menu">
<li id="menu-item-23826" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/">Home</a></li> <li id="menu-item-23824" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/new-home-2/">Home 2</a></li> <li id="menu-item-23823" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/new-home-3/">Home 3</a></li> <li id="menu-item-23822" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/new-home-4/">Home 4</a></li> <li id="menu-item-23821" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/new-home-5/">Home 5</a></li> <li id="menu-item-23849" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostanboxed/">Boxed Version</a></li> 
</ul>
</li><li id="menu-item-23807" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children dropdown"><a href="http://ahmad.works/bostan/blog/" data-target="#" tabindex="-1" data-hover="dropdown" data-delay="200" role="button" class="dropdown-toggle"><span class="menu_icon"><i class="icon-pencil"></i></span>Blog<b class="caret"></b></a>
<ul class="dropdown-menu">
<li id="menu-item-23819" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/blog/">Blog Right Sidebar</a></li> <li id="menu-item-23818" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/blog-left-sidebar/">Blog Left Sidebar</a></li> <li id="menu-item-23795" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/this-is-a-gallery-post/">Gallery Post</a></li> <li id="menu-item-23796" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/a-standard-image-post/">Image Post</a></li> <li id="menu-item-23797" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/this-is-soundcloud-post/">Soundcloud Post</a></li> <li id="menu-item-23798" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/this-is-vimeo-video-post/">Video Post</a></li> 
</ul>
</li><li id="menu-item-23808" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children dropdown"><a href="http://ahmad.works/bostan/portfolio-2/" data-target="#" tabindex="-1" data-hover="dropdown" data-delay="200" role="button" class="dropdown-toggle"><span class="menu_icon"><i class="icon-camera"></i></span>Portfolio<b class="caret"></b></a>
<ul class="dropdown-menu">
<li id="menu-item-23820" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/portfolio-2/">Portfolio</a></li> <li id="menu-item-23837" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/portfolio-2-columns/">Portfolio 2 Columns</a></li> <li id="menu-item-23825" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/portfolio-4-columns/">Portfolio 4 Columns</a></li> <li id="menu-item-23799" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/project/project-6/">Project With Progress</a></li> <li id="menu-item-23800" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/project/project-8/">Left Sidebar Projects</a></li> <li id="menu-item-23801" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/project/project-7/">Gallery Projects</a></li> <li id="menu-item-23803" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://projects.asalahsolutions.com/bostan/project/project-5/">Project With Video</a></li> 
</ul>
</li><li id="menu-item-23791" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown"><a href="#" data-target="#" tabindex="-1" data-hover="dropdown" data-delay="200" role="button" class="dropdown-toggle"><span class="menu_icon"><i class="icon-puzzle"></i></span>Features<b class="caret"></b></a>
<ul class="dropdown-menu">
<li id="menu-item-23810" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/culomns/">Columns</a></li> <li id="menu-item-23811" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/google-map/">Google Map</a></li> <li id="menu-item-23812" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/tabs-and-toggles/">Tabs and Toggles</a></li> <li id="menu-item-23813" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/8887-2/">Boxes and Alerts</a></li> <li id="menu-item-23814" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/buttons/">Buttons</a></li> <li id="menu-item-23815" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/typography/">Typography</a></li> <li id="menu-item-23816" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/videos/">Videos</a></li> <li id="menu-item-23817" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/pricing-table/">Pricing Table</a></li> <li id="menu-item-23827" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/vector-icons/">Vector Icons</a></li> <li id="menu-item-23828" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/post-types-carousel/">Posts and skills</a></li> <li id="menu-item-23802" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://themeforest.net/theme_previews/5030415-bostan-retina-responsive-multipurpose-theme">Option Panel Screenshots</a></li> 
</ul>
</li><li id="menu-item-23809" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://ahmad.works/bostan/contact/"><span class="menu_icon"><i class="icon-paper-plane"></i></span>Contact</a></li></ul></div> </nav>
<div class="mobile primary_menu visible-phone visible-tablet pull-right">
<div id="mobile_menu" class="menu row-fluid">
<select id='primary_menu_mobile' class='top_menu_mobile span12 mobile_menu_select'><option value='' selected='selected'>Go to...</option><option value='http://projects.asalahsolutions.com/bostan/'><span class="menu_icon"><i class="icon-home"></i></span>Home</option><option value='http://ahmad.works/bostan/'> - Home</option><option value='http://ahmad.works/bostan/new-home-2/'> - Home 2</option><option value='http://ahmad.works/bostan/new-home-3/'> - Home 3</option><option value='http://ahmad.works/bostan/new-home-4/'> - Home 4</option><option value='http://ahmad.works/bostan/new-home-5/'> - Home 5</option><option value='http://projects.asalahsolutions.com/bostanboxed/'> - Boxed Version</option><option value='http://ahmad.works/bostan/blog/'><span class="menu_icon"><i class="icon-pencil"></i></span>Blog</option><option value='http://ahmad.works/bostan/blog/'> - Blog Right Sidebar</option><option value='http://ahmad.works/bostan/blog-left-sidebar/'> - Blog Left Sidebar</option><option value='http://projects.asalahsolutions.com/bostan/this-is-a-gallery-post/'> - Gallery Post</option><option value='http://projects.asalahsolutions.com/bostan/a-standard-image-post/'> - Image Post</option><option value='http://projects.asalahsolutions.com/bostan/this-is-soundcloud-post/'> - Soundcloud Post</option><option value='http://projects.asalahsolutions.com/bostan/this-is-vimeo-video-post/'> - Video Post</option><option value='http://ahmad.works/bostan/portfolio-2/'><span class="menu_icon"><i class="icon-camera"></i></span>Portfolio</option><option value='http://ahmad.works/bostan/portfolio-2/'> - Portfolio</option><option value='http://ahmad.works/bostan/portfolio-2-columns/'> - Portfolio 2 Columns</option><option value='http://ahmad.works/bostan/portfolio-4-columns/'> - Portfolio 4 Columns</option><option value='http://projects.asalahsolutions.com/bostan/project/project-6/'> - Project With Progress</option><option value='http://projects.asalahsolutions.com/bostan/project/project-8/'> - Left Sidebar Projects</option><option value='http://projects.asalahsolutions.com/bostan/project/project-7/'> - Gallery Projects</option><option value='http://projects.asalahsolutions.com/bostan/project/project-5/'> - Project With Video</option><option value='#'><span class="menu_icon"><i class="icon-puzzle"></i></span>Features</option><option value='http://ahmad.works/bostan/culomns/'> - Columns</option><option value='http://ahmad.works/bostan/google-map/'> - Google Map</option><option value='http://ahmad.works/bostan/tabs-and-toggles/'> - Tabs and Toggles</option><option value='http://ahmad.works/bostan/8887-2/'> - Boxes and Alerts</option><option value='http://ahmad.works/bostan/buttons/'> - Buttons</option><option value='http://ahmad.works/bostan/typography/'> - Typography</option><option value='http://ahmad.works/bostan/videos/'> - Videos</option><option value='http://ahmad.works/bostan/pricing-table/'> - Pricing Table</option><option value='http://ahmad.works/bostan/vector-icons/'> - Vector Icons</option><option value='http://ahmad.works/bostan/post-types-carousel/'> - Posts and skills</option><option value='http://themeforest.net/theme_previews/5030415-bostan-retina-responsive-multipurpose-theme'> - Option Panel Screenshots</option><option value='http://ahmad.works/bostan/contact/'><span class="menu_icon"><i class="icon-paper-plane"></i></span>Contact</option></select> </div>
</div>
</div></div></div>
</div>
</div>
 
<div class="header_shadow_separator"></div>
</header>
 
<div class="body_width site_middle_content"> 
<div class="page_title_holder container-fluid">
<div class="container">
<div class="page_info">
<h1>404 Error</h1>
<nav class="breadcrumb"><a href="http://ahmad.works/bostan/">Home</a> <span class="divider">&raquo;</span> Not found</nav> </div>
<div class="page_nav">
</div>
</div>
</div>
 
<section class="main_content">
 
<div class="container blog_style_1 blog_page blog_posts new_section">
<div class="row-fluid">
<div class="span12">
<article class="blog_post">
<div class="blog_banner clearfix">
<h2>Sorry</h2>
<h3>It seems we can't find what you're looking for.</h3>
</div>
</article>
</div>
</div>
</div>
 
</section> 
</div>  
<footer class="container-fluid site_footer body_width">
<div class="container">
<div class="row-fluid">
<div id="first_footer" class="widget_area span3">
<div id="text-2" class="widget_container clearfix widget widget_text"><h3 class="page-header"><span class="page_header_title">Bostan.</span></h3> <div class="textwidget">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec iaculis metus vitae ligula elementum ut luctus lorem facilisis. Sed non leo nisl, ac euismod nisi. Aenean augue dolor, facilisis id fringilla ut. tempus vitae nibh. Nullam nec diam risus.</div>
</div> </div>
<div id="second_footer" class="widget_area span3">
<div id="quick-flickr-widget-2" class="widget_container clearfix widget widget_quick-flickr-widget"><h3 class="page-header"><span class="page_header_title">Photostream</span></h3>SSL is required</div> </div>
<div id="third_footer" class="widget_area span3">
<div id="text-3" class="widget_container clearfix widget widget_text"><h3 class="page-header"><span class="page_header_title">Contact Info.</span></h3> <div class="textwidget">123 Street St. City, CN 10044
<br/><br/>
+2-12-3335557
<br/><br/>
<a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="bfd6d1d9d0ffd2ded6d391dcd0d2">[email&#160;protected]</a><script cf-hash='f9e31' type="text/javascript">
/* <![CDATA[ */!function(){try{var t="currentScript"in document?document.currentScript:function(){for(var t=document.getElementsByTagName("script"),e=t.length;e--;)if(t[e].getAttribute("cf-hash"))return t[e]}();if(t&&t.previousSibling){var e,r,n,i,c=t.previousSibling,a=c.getAttribute("data-cfemail");if(a){for(e="",r=parseInt(a.substr(0,2),16),n=2;a.length-n;n+=2)i=parseInt(a.substr(n,2),16)^r,e+=String.fromCharCode(i);e=document.createTextNode(e),c.parentNode.replaceChild(e,c)}}}catch(u){}}();/* ]]> */</script>
<br/><br/>
www.a-salah.com
<br/><br/></div>
</div> </div>
<div id="fourth_footer" class="widget_area span3">
<div id="tag_cloud-5" class="widget_container clearfix widget widget_tag_cloud"><h3 class="page-header"><span class="page_header_title">Explore.</span></h3><div class="tagcloud"><a href='http://ahmad.works/bostan/tag/business/' class='tag-link-2' title='3 topics' style='font-size: 22pt;'>Business</a>
<a href='http://ahmad.works/bostan/tag/image/' class='tag-link-6' title='2 topics' style='font-size: 16.4pt;'>Image</a>
<a href='http://ahmad.works/bostan/tag/politics/' class='tag-link-4' title='2 topics' style='font-size: 16.4pt;'>Politics</a>
<a href='http://ahmad.works/bostan/tag/technology/' class='tag-link-7' title='3 topics' style='font-size: 22pt;'>Technology</a>
<a href='http://ahmad.works/bostan/tag/video/' class='tag-link-8' title='1 topic' style='font-size: 8pt;'>video</a>
<a href='http://ahmad.works/bostan/tag/youtube/' class='tag-link-9' title='1 topic' style='font-size: 8pt;'>youtube</a></div>
</div><div id="text-4" class="widget_container clearfix widget widget_text"> <div class="textwidget"></div>
</div><div id="search-6" class="widget_container clearfix widget widget_search"><form class="search clearfix" method="get" id="searchform" action="http://ahmad.works/bostan/">
<input class="span12 search_text" id="appendedInputButton" placeholder="Type and hit Enter" type="text" name="s">
</form>
</div> </div>
</div>
</div>
</footer>
<div class="container-fluid site_secondary_footer body_width">
<div class="container secondary_footer_container">
<div class="row-fluid">
<div class="pull-left">
All rights reserved, Bostan 2013 </div>
</div>
</div>
</div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-43776399-4', 'auto');
  ga('send', 'pageview');

</script> <script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/framework/aqua/assets/js/aqpb-view.js?ver=1433908950'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/ahmad.works\/bostan\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ...","cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.1.1'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/framework/bootstrap/js/bootstrap.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/eslider/jquery.eislideshow.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.fitvids.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.ticker.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/flexslider/jquery.flexslider-min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.easing.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/owl-carousel/owl.carousel.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/prettyphoto/js/jquery.prettyPhoto.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.mousewheel.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/carousel/jquery.carouFredSel-6.2.0-packed.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.touchSwipe.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.jcarousel.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.transit.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/jquery.ba-throttle-debounce.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/component.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/isotope/jquery.isotope.min.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/tweets/jquery.tweet.js?ver=4.1.5'></script>
<script type='text/javascript' src='http://ahmad.works/bostan/wp-content/themes/bostan/js/asalah.js?ver=2.4'></script>
</body>
</html>
 